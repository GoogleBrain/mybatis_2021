package mybatisday01.main;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import mybatisday01.domain.Department;
import mybatisday01.domain.Student;
import mybatisday01.mapper.DepartmentMapper;
import mybatisday01.mapper.StudentMapper;

public class App {
	public static void main(String[] args) throws IOException {
		// String name="mybatis-config.xml";
		// InputStream resourceAsStream = Resources.getResourceAsStream(name);
		//
		// SqlSessionFactory build = new
		// SqlSessionFactoryBuilder().build(resourceAsStream);
		// SqlSession openSession = build.openSession();
		// Student selectOne =
		// openSession.selectOne("com.atguigu.mybatis.dao.StudentMapper.getBystudentId",1);
		// System.out.println(selectOne);
		// openSession.close();

		// /**
		// * �·���������ӿڱ��
		// */
		// String name="mybatis-config.xml";
		// InputStream resourceAsStream = Resources.getResourceAsStream(name);
		//
		// SqlSessionFactory build = new
		// SqlSessionFactoryBuilder().build(resourceAsStream);
		// SqlSession openSession = build.openSession();
		// StudentMapper selectOne = openSession.getMapper(StudentMapper.class);
		// Student stu = selectOne.getBystudentId(1);
		// System.out.println(stu);
		// openSession.close();

		/**
		 * �·���������ӿڱ��
		 */
		String name = "mybatis-config.xml";
		InputStream resourceAsStream = Resources.getResourceAsStream(name);

		SqlSessionFactory build = new SqlSessionFactoryBuilder().build(resourceAsStream);
		SqlSession openSession = build.openSession();
		StudentMapper selectOne = openSession.getMapper(StudentMapper.class);
		// ��ѯ
		// List<Integer> asList = Arrays.asList(1);
		// Student stu = selectOne.getByStudentId2(asList);
		// System.out.println(stu);
		// ��ѯ
		// Integer[] a = { 1 };
		// Student stu = selectOne.getByStudentId4(a);
		// System.out.println(stu);

		// ��ѯ
		// Student stu = selectOne.getBystudentId(1);
		// System.out.println(stu);

		// ����
		// Student stu = new Student("li", "li@163.com", 1);
		// selectOne.addStudent(stu);
		// System.out.println(stu.getId());
		// openSession.commit();
		// ����
		// selectOne.addStudent2("a","b",1);
		// openSession.commit();
		// ����
		// Student stu = new Student("li", "li@163.com", 1);
		// selectOne.addStudent(stu);
		// System.out.println(stu.getId());
		// openSession.commit();
		// ����
//		 Map<String,Object>map = new HashMap<String,Object>();
//		 map.put("aa", "laowang");
//		 map.put("bb", "222@163.com");
//		 map.put("gender", 1);
//		 Integer addStudent4 = selectOne.addStudent4(map);
//		 System.out.println(map.get("id"));
//		 openSession.commit();

		// �޸�
		// Student stu = new Student(2,"lili","lili@163.com",2);
		// selectOne.updateStudent(stu);
		// openSession.commit();

		// ɾ��
		// selectOne.deleteStudent(2);
		// openSession.commit();
		
		//��ѯ
//		Student selecyByidandname = selectOne.selecyByidandname2(3,"student");
//		System.out.println(selecyByidandname.toString());
		
		//����list
//		List<Student> selectByUserName = selectOne.selectByUserName("li");
//		for(Student stu:selectByUserName){
//			System.out.println(stu);
//		}
		
//		Map<String, Object> returnmapByid = selectOne.returnmapByid(1);
//		System.out.println(returnmapByid);
		
//		Map<Integer, Student> studentByLastNameLike = selectOne.getStudentByLastNameLike("li");
//		System.out.println(studentByLastNameLike.get(3));
		
//		Student selectbyresultmap = selectOne.selectbyresultmap(1);
//		System.out.println(selectbyresultmap);
		
//		Student lianhechaxun = selectOne.lianhechaxun();
//		System.out.println(lianhechaxun);
		
//		Student lianhechaxun = selectOne.lianhechaxun2();
//		System.out.println(lianhechaxun);
		
//		Student selectUserByStep = selectOne.selectUserByStep(1);
//		System.out.println(selectUserByStep.getLastName());
//		System.out.println(selectUserByStep.getDepart());
		
		Student selectUserByStep = selectOne.getDepartmentPlusDis(8);
		System.out.println(selectUserByStep);
		//-----------------------------------------------
//		DepartmentMapper selectOne = openSession.getMapper(DepartmentMapper.class);
//		Department departmentPlus = selectOne.getDepartmentPlus(1);
//		System.out.println(departmentPlus);
//		System.out.println(departmentPlus.getStus());
		
//		Department departmentPlus = selectOne.getDepartmentPlusStep(1);
//		System.out.println(departmentPlus);
//		System.out.println(departmentPlus.getStus());
		openSession.close();
	}
}
