package mybatisday01.mapper;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Param;

import mybatisday01.domain.Student;

public interface StudentMapper {
	
	public Student getBystudentId(Integer id);
	public Student getByStudentId2(List<Integer> ids);
	
	public Student getByStudentId3(Set<Integer> ids);
	
	public Student getByStudentId4(Integer[] ids);
	
	public Integer addStudent(Student stu);
	
	public Integer addStudent2(@Param("a") String a,@Param("b")String b,@Param("c") Integer c);
	
	public Integer addStudent4(Map map);
	
	public boolean updateStudent(Student stu);
	
	public Integer deleteStudent(Integer id); 
	
	public Student selecyByidandname(@Param("id")  Integer a,@Param("lastname") String lastname);
	
	public Student selecyByidandname2(@Param("id")  Integer a,@Param("tablename") String tablename);
	
	public List<Student>selectByUserName(String name);
	
	public Map<String,Object>returnmapByid(Integer id);
	
	@MapKey(value="id")//��װmap��key��ʱ��ʹ��id��Ϊ������
	public Map<Integer,Student>getStudentByLastNameLike(String lastName);
	
	public Student selectbyresultmap(Integer id);
	
	public Student lianhechaxun();
	public Student lianhechaxun2();
	
	public Student selectUserByStep(Integer id);
	
	public List<Student> getStudentByDept(Integer deptid);
	
	public Student getDepartmentPlusDis(Integer id);

}
