package mybatisday01.domain;

import java.util.List;

public class Department {
	
	private Integer id;
	private String departName;
	
	private List<Student> stus;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDepartName() {
		return departName;
	}
	public void setDepartName(String departName) {
		this.departName = departName;
	}
	
	
	public List<Student> getStus() {
		return stus;
	}
	public void setStus(List<Student> stus) {
		this.stus = stus;
	}
	@Override
	public String toString() {
		return "Department [id=" + id + ", departName=" + departName + ", stus=" + stus + "]";
	}
}
