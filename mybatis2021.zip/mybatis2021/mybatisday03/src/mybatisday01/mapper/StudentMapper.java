package mybatisday01.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import mybatisday01.domain.Student;

public interface StudentMapper {
	
	public Student getBystudentId(@Param("list")List list);
	
}
