package mybatisday01.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import mybatisday01.domain.Student;

public interface StudentMapper {
	
	public List<Student> getBystudentId(Student stu);
	
	public List<Student> getBystudentId2(Student stu);
	
	public List<Student> getBystudentId3(Student stu);
	
	public List<Student> getBystudentId4(Student stu);
	
	public List<Student> selectforeach(List<Integer>idss);
	
	public void addStudent(@Param("stus") List<Student>stus);
	
	public List<Student> likelist(Student stu);

}
