package mybatisday01.main;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import mybatisday01.domain.Student;
import mybatisday01.mapper.StudentMapper;

public class App {
	public static void main(String[] args) throws IOException {
		/**
		 * �·���������ӿڱ��
		 */
		String name = "mybatis-config.xml";
		InputStream resourceAsStream = Resources.getResourceAsStream(name);

		SqlSessionFactory build = new SqlSessionFactoryBuilder().build(resourceAsStream);
		SqlSession openSession = build.openSession();
		StudentMapper selectOne = openSession.getMapper(StudentMapper.class);
//		// ��ѯ
//		List<Student> stus = selectOne.getBystudentId4(null);
//		for(Student st:stus){
//			System.out.println(st);
//		}
		
//		List<Student> selectforeach = selectOne.selectforeach(Arrays.asList(1,2,3,4));
//		for(Student stu:selectforeach){
//			System.out.println(stu);
//		}
		
//		List<Student>lists = new ArrayList<>();
//		Student s1 = new Student();
//		s1.setLastName("s1");
//		
//		Student s2 = new Student();
//		s2.setLastName("s2");
//		
//		lists.add(s1);
//		lists.add(s2);
//		selectOne.addStudent(lists);
//		openSession.commit();
		Student stu = new Student();
		stu.setLastName("%i%");
		List<Student> likelist = selectOne.likelist(stu);

		for(Student su:likelist){
			System.out.println(su.toString());
		}
		openSession.close();
	}
}
