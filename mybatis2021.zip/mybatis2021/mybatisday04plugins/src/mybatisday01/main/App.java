package mybatisday01.main;

import java.io.IOException;
import java.io.InputStream;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import mybatisday01.domain.Student;
import mybatisday01.mapper.StudentMapper;

public class App {
	public static void main(String[] args) throws IOException {

		String name = "mybatis-config.xml";
		InputStream resourceAsStream = Resources.getResourceAsStream(name);

		SqlSessionFactory build = new SqlSessionFactoryBuilder().build(resourceAsStream);
		SqlSession openSession = build.openSession();
		StudentMapper selectOne = openSession.getMapper(StudentMapper.class);
		Student stus = selectOne.getBystudentId(1);
		System.out.println(selectOne);
		System.out.println(stus);
		openSession.close();
	}
}
