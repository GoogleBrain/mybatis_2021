package mybatisday01.mapper;

import java.util.List;

import mybatisday01.domain.Student;

public interface StudentMapper {
	
	public List<Student> getBystudentId();
	
	public void addStudents(Student stu);
	
}
