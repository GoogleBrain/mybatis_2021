package mybatisday01.main;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import mybatisday01.domain.Student;
import mybatisday01.mapper.StudentMapper;

public class App {
	public static void main(String[] args) throws IOException {
		/**
		 * 1.��ȡsqlSessionFactory����
		 * 2.��ȡsqlSession����
		 * 3.��ȡ�ӿڵĴ�������MapperProxy)
		 * 4.ִ����ɾ�Ĳ鷽����
		 * 
		 */
		String name = "mybatis-config.xml";
		InputStream resourceAsStream = Resources.getResourceAsStream(name);

		SqlSessionFactory build = new SqlSessionFactoryBuilder().build(resourceAsStream);
		//��ҳ
//		SqlSession openSession = build.openSession();
//		StudentMapper selectOne = openSession.getMapper(StudentMapper.class);
//		Page<Object> startPage = PageHelper.startPage(7,1);
//		List<Student> stus = selectOne.getBystudentId();
//		for(Student stu:stus){
//			System.out.println(stu);
//		}
//		
//		System.out.println(startPage.getPageNum());
//		System.out.println(startPage.getTotal());
//		System.out.println(startPage.getPages());
//		System.out.println("---------");
//		PageInfo<Student> pageInfo = new PageInfo<>(stus);
//		System.out.println(pageInfo);
//		System.out.println("-----������ʾ��ҳ��----");
//		PageInfo<Student> pageInfo2 = new PageInfo<>(stus,5);
//		int[] a = pageInfo2.getNavigatepageNums();
//		for(int b:a){
//			System.out.println(b);
//		}
		
		//��������������
		SqlSession openSession = build.openSession(ExecutorType.BATCH);
		StudentMapper mapper = openSession.getMapper(StudentMapper.class);
		for(int i=0;i<10;i++){
			mapper.addStudents(new Student("i"+i, "i@"+i, i));
		}
		
		openSession.close();
	}
}
